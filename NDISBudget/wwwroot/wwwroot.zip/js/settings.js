﻿$(() => {
    var currpageurl = window.location.href.toLowerCase();
    var area = "Admin";
    var manageCategoriesUrl = websiteurl + "/" + area + "/Settings/Categories";
    var managePricesUrl = websiteurl + "/" + area + "/Settings/Prices";
    var createItemsUrl = websiteurl + "/" + area + "/Settings/Items";

    
    // Manage Promotions Page
    if (currpageurl.indexOf(manageCategoriesUrl.toLowerCase()) != -1) {

        //alert(1)
        getCategories();
        $(document).on('click', '#addentitry', function (event) {
            window.location.href = '/Admin/Settings/AddCategories';
        });

        $(document).on('click', '#btnEdit', function (event) {
            var id = $(this).attr('data-cid');
            window.location.href = '/Admin/Settings/AddCategories?id=' + id;
        });

        $(document).on('click', '#btndelete', function (event) {
            var id = $(this).attr('data-cid');
            //alert(id)
            gl.ajaxreqloader(apiurl + "Settings/DeleteCategory", "GET", { id: id }, function (response) {
                //alert(response)
                getCategories();
            });
        });

        function getCategories() {
            BindCategories(1, 10, 1, '');
            $('#shwbtn').click(function (event) {
                event.preventDefault();
                //alert($('#SearchStr').val())
                var Searchstr = $('#SearchStr').val();
                BindCategories(1, 10, 1, Searchstr);
            });

            $(document).on('click', '#shwallbtn', function (event) {
                $('#SearchStr').val('')
                BindCategories(1, 10, 1, '');
            });
            $(document).on("click", ".d-paging", function (event) {
                var pagesize = $('#ddlpagesize').val();
                var pageindex = $(this).attr('_id');
                var Searchstr = $('#SearchStr').val();
                BindCategories(pageindex, pagesize, 1, Searchstr);
            });
            $(document).on("change", '#ddlpagesize', function (event) {
                var Searchstr = $('#SearchStr').val();
                var pagesize = $('#ddlpagesize').val();
                var pageindex = 1;
                var sortby = 1; //$('#SortBy').val();
                BindCategories(pageindex, pagesize, 1, Searchstr);
            });
        }
        function BindCategories(pageindex, pagesize, sortby, strname) {
            //alert(strname)
            var dataParams = {
                CompanyId: $('#CompanyId').val(),
                pgsize: pagesize,
                pgindex: pageindex,
                str: strname,
                sortby: sortby,
                "fromDate": "",
                "toDate": "",
                "committee": 0
            }
            console.log(dataParams);
            var row = '';
            var reccount = 0;
            gl.ajaxreqloader(apiurl + "Settings/GetAdminCategoriyList", "POST", dataParams, function (response) {
                console.log(response);
                if (response.length > 0) {
                    reccount = response[0].totalRecords;
                    $.each(response, function (i, item) {

                        row += "<tr><td>" + item.supportCategoryName + "</td><td>" + item.status + "</td><td>" + item.createdDateStr + "</td><td><a href='javascript:;' title='Edit' id='btnEdit' data-toggle='modal' data-target='#update' data-cid=" + item.supportCategoryId + "><i class='fa fa-edit m-r-5'></i></a>&nbsp;&nbsp;&nbsp;<a href='javascript:;' title='Delete' id='btndelete'  data-cid=" + item.supportCategoryId + "><i class='fa fa-remove m-r-5'></i></a></td></tr>";

                    });
                    $("#tbldata").html(row);
                    setPagging(reccount, pageindex, pagesize);
                    $('.norec').addClass('hide');
                    $('.tblcontent').removeClass('hide');
                }
                else {
                    if (String(strname).length > 0) {
                        $('.norec').addClass('hide');
                        $('.tblcontent').removeClass('hide');
                        $("#tbldata").html("<tr><td>No Data Found</td></td></tr>");
                    }
                    else {
                        $('.norec').removeClass('hide');
                        $('.tblcontent').addClass('hide');
                    }
                }
            }, '', '', '', '', true, true, '.loader', '.tblcontent', 'text json', 'true');

        }
    }
    else if (currpageurl.indexOf(createItemsUrl.toLowerCase()) != -1) {
        getItems();
        $(document).on('click', '#addentitry', function (event) {
            window.location.href = '/Admin/Settings/AddItems';
        });

        $(document).on('click', '#btnEdit', function (event) {
            var id = $(this).attr('data-cid');
            window.location.href = '/Admin/Settings/AddItems?id=' + id;
        });
        $(document).on('click', '#btncopy', function (event) {
            var id = $(this).attr('data-cid');
            window.location.href = '/Admin/Settings/AddItems?id=' + id+'&Copy=1';
        });

        $(document).on('click', '#btndelete', function (event) {
            var id = $(this).attr('data-cid');
            //alert(id)
            gl.ajaxreqloader(apiurl + "Settings/DeleteItem", "GET", { id: id }, function (response) {
                //alert(response)
                getItems();
            });
        });

        function getItems() {
            BindItems(1, 10, 1, '');
            $('#shwbtn').click(function (event) {
                event.preventDefault();
                //alert($('#SearchStr').val())
                var Searchstr = $('#SearchStr').val();
                BindItems(1, 10, 1, Searchstr);
            });

            $(document).on('click', '#shwallbtn', function (event) {
                $('#SearchStr').val('')
                BindItems(1, 10, 1, '');
            });
            $(document).on("click", ".d-paging", function (event) {
                var pagesize = $('#ddlpagesize').val();
                var pageindex = $(this).attr('_id');
                var Searchstr = $('#SearchStr').val();
                BindItems(pageindex, pagesize, 1, Searchstr);
            });
            $(document).on("change", '#ddlpagesize', function (event) {
                var Searchstr = $('#SearchStr').val();
                var pagesize = $('#ddlpagesize').val();
                var pageindex = 1;
                var sortby = 1; //$('#SortBy').val();
                BindItems(pageindex, pagesize, 1, Searchstr);
            });
        }
        function setCustomName(x) {
            return x == null ? '' : x;
        }
        function BindItems(pageindex, pagesize, sortby, strname) {
            //alert(strname)
            var dataParams = {
                CompanyId: $('#CompanyId').val(),
                pgsize: pagesize,
                pgindex: pageindex,
                str: strname,
                sortby: sortby,
                "fromDate": "",
                "toDate": "",
                "committee": 0
            }
            console.log(dataParams);
            var row = '';
            var reccount = 0;
            gl.ajaxreqloader(apiurl + "Settings/GetAdminSupportItemList", "POST", dataParams, function (response) {
                console.log(response);
                if (response.length > 0) {
                    reccount = response[0].totalRecords;
                    $.each(response, function (i, item) {

                        row += "<tr><td>" + item.supportItemNumber + "</td><td>" + item.supportItemName + "</td><td>" + item.supportCategoryName + "</td><td>" + setCustomName(item.customName) + "</td><td>" + item.isActive + "</td><td><a href='javascript:;' id='btnEdit' data-toggle='modal' data-target='#update' data-cid=" + item.supportItemId + "><i class='fa fa-edit m-r-5'></i></a>&nbsp;&nbsp;&nbsp;<a href='javascript:;' title='Delete' id='btncopy'  data-cid=" + item.supportItemId + "><i class='fa fa-remove m-r-5'></i></a>&nbsp;&nbsp;&nbsp;<a href='javascript:;' title='Copy' id='btncopy'  data-cid=" + item.supportItemId + "><i class='fa fa-copy m-r-5'></i></a></td></tr>";

                    });
                    $("#tbldata").html(row);
                    setPagging(reccount, pageindex, pagesize);
                    $('.norec').addClass('hide');
                    $('.tblcontent').removeClass('hide');
                }
                else {
                    if (String(strname).length > 0) {
                        $('.norec').addClass('hide');
                        $('.tblcontent').removeClass('hide');
                        $("#tbldata").html("<tr><td>No Data Found</td></td></tr>");
                    }
                    else {
                        $('.norec').removeClass('hide');
                        $('.tblcontent').addClass('hide');
                    }
                }
            }, '', '', '', '', true, true, '.loader', '.tblcontent', 'text json', 'true');

        }
    }
    else if (currpageurl.indexOf(managePricesUrl.toLowerCase()) != -1) {
        getPrices();
        $(document).on('click', '#addentitry', function (event) {
            window.location.href = '/Admin/Settings/AddPrices';
        });

        $(document).on('click', '#btnEdit', function (event) {
            var id = $(this).attr('data-cid');
            window.location.href = '/Admin/Settings/AddPrices?id=' + id;
        });

        $(document).on('click', '#btndelete', function (event) {
            var id = $(this).attr('data-cid');
            //alert(id)
            gl.ajaxreqloader(apiurl + "Settings/DeletePrices", "GET", { id: id }, function (response) {
                //alert(response)
                getPrices();
            });
        });

        function getPrices() {
            BindPrices(1, 10, 1, '');
            $('#shwbtn').click(function (event) {
                event.preventDefault();
                //alert($('#SearchStr').val())
                var Searchstr = $('#SearchStr').val();
                BindPrices(1, 10, 1, Searchstr);
            });

            $(document).on('click', '#shwallbtn', function (event) {
                $('#SearchStr').val('')
                BindPrices(1, 10, 1, '');
            });
            $(document).on("click", ".d-paging", function (event) {
                var pagesize = $('#ddlpagesize').val();
                var pageindex = $(this).attr('_id');
                var Searchstr = $('#SearchStr').val();
                BindPrices(pageindex, pagesize, 1, Searchstr);
            });
            $(document).on("change", '#ddlpagesize', function (event) {
                var Searchstr = $('#SearchStr').val();
                var pagesize = $('#ddlpagesize').val();
                var pageindex = 1;
                var sortby = 1; //$('#SortBy').val();
                BindPrices(pageindex, pagesize, 1, Searchstr);
            });
        }
        function BindPrices(pageindex, pagesize, sortby, strname) {
            //alert(strname)
            var dataParams = {
                CompanyId: $('#CompanyId').val(),
                pgsize: pagesize,
                pgindex: pageindex,
                str: strname,
                sortby: sortby,
                "fromDate": "",
                "toDate": "",
                "committee": 0
            }
            console.log(dataParams);
            var row = '';
            var reccount = 0;
            gl.ajaxreqloader(apiurl + "Settings/GetAdminSupportItemPriceList", "POST", dataParams, function (response) {
                console.log(response);
                if (response.length > 0) {
                    reccount = response[0].totalRecords;
                    $.each(response, function (i, item) {

                        row += "<tr><td>" + item.supportItemName + "</td><td>" + item.stateName + "</td><td>" + item.price + "</td><td>" + item.isActive + "</td><td>" + item.createdDateStr + "</td><td><a href='javascript:;' title='Edit' id='btnEdit' data-toggle='modal' data-target='#update' data-cid=" + item.supportItemPriceListId + "><i class='fa fa-edit m-r-5'></i></a>&nbsp;&nbsp;&nbsp;<a href='javascript:;' title='Delete' id='btndelete'  data-cid=" + item.supportItemPriceListId + "><i class='fa fa-remove m-r-5'></i></a></td></tr>";

                    });
                    $("#tbldata").html(row);
                    setPagging(reccount, pageindex, pagesize);
                    $('.norec').addClass('hide');
                    $('.tblcontent').removeClass('hide');
                }
                else {
                    if (String(strname).length > 0) {
                        $('.norec').addClass('hide');
                        $('.tblcontent').removeClass('hide');
                        $("#tbldata").html("<tr><td>No Data Found</td></td></tr>");
                    }
                    else {
                        $('.norec').removeClass('hide');
                        $('.tblcontent').addClass('hide');
                    }
                }
            }, '', '', '', '', true, true, '.loader', '.tblcontent', 'text json', 'true');

        }
    }



});




